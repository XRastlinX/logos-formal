# Group Rules

1. Local sessions are interpretive. They do not authorize.
2. Local model output remains local until deliberately proposed through Git.
3. Shared changes use a branch or pull request with recoverable lineage.
4. Provenance and declared derivation travel with the artifact.
5. A derivative document does not become an independent source by repetition.
6. No participant possesses ambient group authority.
7. Failed and rejected experiments remain visible when retaining them is safe
   and lawful.
8. Secrets, credentials, private keys, and private transcripts do not enter the
   shared repository.
9. The current main line is the best recorded working state, not final truth.
10. The protected repository and its human-governed review process remain the
    elevation boundary.

