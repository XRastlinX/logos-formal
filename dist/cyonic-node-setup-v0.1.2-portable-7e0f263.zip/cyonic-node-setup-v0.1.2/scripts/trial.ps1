param(
    [string]$Report = "cyonic-first-contact-report-01.json"
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$CanonDir = Join-Path $Root "canon\logos-formal"
$Executable = Join-Path $Root ".cache\cyonic-service.exe"
$Manifest = Get-Content -LiteralPath (Join-Path $Root "VERSION.json") -Raw | ConvertFrom-Json

if (-not (Test-Path -LiteralPath (Join-Path $CanonDir ".git"))) {
    throw "Canon checkout is missing. Run setup.cmd first."
}

$ActualCommit = (& git -C $CanonDir rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $ActualCommit -ne $Manifest.sourceCommit) {
    throw "Canon checkout does not match the pinned source commit."
}
if (& git -C $CanonDir status --porcelain) {
    throw "Canon checkout has local changes; the trial requires the pinned clean tree."
}
if (-not (Test-Path -LiteralPath $Executable)) {
    throw "Validated service executable is missing. Run validate.cmd first."
}

if ([System.IO.Path]::IsPathRooted($Report)) {
    $ReportPath = [System.IO.Path]::GetFullPath($Report)
}
else {
    $ReportPath = [System.IO.Path]::GetFullPath((Join-Path $Root $Report))
}

Push-Location $CanonDir
try {
    & $Executable trial `
        -origin external `
        -report $ReportPath
    $TrialExitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}

if ($TrialExitCode -ne 0) {
    Write-Host "First Contact trial failed with exit code $TrialExitCode." -ForegroundColor Red
    exit $TrialExitCode
}

Write-Host ""
Write-Host "FIRST_CONTACT_REPORT_CREATED" -ForegroundColor Green
Write-Host "Report: $ReportPath"
Write-Host "Status: PENDING_EXTERNAL_REVIEW"
Write-Host "Authority effect: NONE"
