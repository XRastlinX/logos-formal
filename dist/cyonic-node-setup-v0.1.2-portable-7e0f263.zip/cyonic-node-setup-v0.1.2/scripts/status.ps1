$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Manifest = Get-Content -LiteralPath (Join-Path $Root "VERSION.json") -Raw | ConvertFrom-Json
$CanonDir = Join-Path $Root "canon\logos-formal"

Write-Host "Node Setup: $($Manifest.packageVersion)"
Write-Host "Expected commit: $($Manifest.sourceCommit)"
Write-Host "Governance state: $($Manifest.governanceState)"
Write-Host "Authority effect: $($Manifest.authorityEffect)"

$configPath = Join-Path $Root "config\node.yaml"
if (Test-Path -LiteralPath $configPath) {
    Write-Host ""
    Get-Content -LiteralPath $configPath
}

if (Test-Path -LiteralPath (Join-Path $CanonDir ".git")) {
    $actual = (& git -C $CanonDir rev-parse HEAD).Trim()
    $dirty = & git -C $CanonDir status --porcelain
    Write-Host ""
    Write-Host "Actual commit: $actual"
    Write-Host "Pinned commit match: $($actual -eq $Manifest.sourceCommit)"
    Write-Host "Working tree clean: $(-not [bool]$dirty)"
}
else {
    Write-Host "Canon checkout: MISSING"
}

