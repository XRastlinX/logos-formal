#!/usr/bin/env bash
set -euo pipefail

IDENTITY="${1:-friend-node-01}"
PATHWAY="${2:-codex}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CANON_DIR="$ROOT/canon/logos-formal"
REPOSITORY="https://github.com/XRastlinX/logos-formal.git"
SOURCE_BRANCH="codex/cyonic-service-surface-v1"
SOURCE_COMMIT="7e0f263c2a31eaece5bf8ded76ce4ba47c7db32a"

[[ "$IDENTITY" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || {
  echo "Invalid node identity." >&2
  exit 2
}
case "$PATHWAY" in
  codex|antigravity|manual) ;;
  *) echo "Pathway must be codex, antigravity, or manual." >&2; exit 2 ;;
esac

command -v git >/dev/null || { echo "Git is required." >&2; exit 2; }
command -v go >/dev/null || { echo "Go 1.24+ is required." >&2; exit 2; }

if [[ -d "$CANON_DIR/.git" ]]; then
  [[ -z "$(git -C "$CANON_DIR" status --porcelain)" ]] || {
    echo "Existing canon checkout has local changes; refusing to discard them." >&2
    exit 2
  }
elif [[ -e "$CANON_DIR" ]]; then
  echo "Canon path exists but is not a Git checkout: $CANON_DIR" >&2
  exit 2
else
  git clone --filter=blob:none --no-checkout "$REPOSITORY" "$CANON_DIR"
fi

git -C "$CANON_DIR" fetch origin "$SOURCE_BRANCH"
git -C "$CANON_DIR" switch --detach "$SOURCE_COMMIT"
[[ "$(git -C "$CANON_DIR" rev-parse HEAD)" == "$SOURCE_COMMIT" ]]

if [[ ! -f "$ROOT/config/node.yaml" ]]; then
  sed -e "s/NODE_ID/$IDENTITY/g" -e "s/PATHWAY/$PATHWAY/g" \
    "$ROOT/config/node.example.yaml" > "$ROOT/config/node.yaml"
fi

"$ROOT/scripts/validate.sh"

printf '\nNODE_SETUP_COMPLETE\n'
printf 'Node: %s\nPathway: %s\nPinned commit: %s\n' "$IDENTITY" "$PATHWAY" "$SOURCE_COMMIT"
printf 'Local sessions remain 010 with authority_effect NONE.\n'
