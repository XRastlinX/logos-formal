# Canon pointer

The setup scripts clone the public repository here as:

```text
canon/logos-formal
```

The checkout is detached at the exact `sourceCommit` declared in
`../VERSION.json`. A detached checkout prevents local branch names from being
mistaken for shared elevation.

