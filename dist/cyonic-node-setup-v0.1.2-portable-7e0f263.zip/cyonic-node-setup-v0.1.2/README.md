# Cyonic Node Setup v0.1.2

This package creates a local node for a small group sharing a Git-anchored
epistemic ledger.

Your AI sessions remain at governance state `010`: they may inspect, explain,
test, and propose. They do not authorize, Apply, merge, or turn a local session
result into group knowledge.

The node pins the public `logos-formal` repository to one exact commit. Its
validation path first binds the checkout to an exact tree root, then runs the
first Cyonic Service Surface as a local, read-only HTTP verifier.

## What this is

- a reproducible local checkout of the public canon;
- a repository-bound 5/5 validation receipt over exact bytes;
- a standalone `010` validation service;
- a cold-call probe for its two HTTP aliases;
- local node identity and pathway configuration;
- a clear route for proposing changes through Git.

## What this is not

- an autonomous agent;
- an Apply gateway;
- a source of permits or ambient group authority;
- a synchronization channel for private model memory;
- proof that an interpretation is true, safe, lawful, or canonical.

## Windows setup

Requires Git and Go 1.24+:

```powershell
.\setup.cmd friend-node-01 codex
```

The `.cmd` wrapper avoids the default PowerShell script-execution-policy
friction.

Run the validation again:

```powershell
.\validate.cmd
```

Record a First Contact participant report:

```powershell
.\trial.cmd cyonic-first-contact-report-01.json
```

Show the node's pinned source and local status:

```powershell
.\status.cmd
```

## Linux or macOS setup

```bash
chmod +x scripts/*.sh
./scripts/setup.sh friend-node-01 codex
./scripts/validate.sh
./scripts/trial.sh cyonic-first-contact-report-01.json
./scripts/status.sh
```

The trial command is interactive. It records the tester's elapsed time,
explanation, and friction alongside the observed `010` boundary receipt.
Reports are create-only and remain `CLAIMED_EXTERNAL`,
`PENDING_EXTERNAL_REVIEW`, and `authorityEffect: NONE` until reviewed
separately.

## Expected validation results

Repository validation:

```text
X-Cubed-Bit: 010
X-Validator-Operator: 000
X-Governance-Authority-Effect: NONE
X-Execution-Containment: HOST
X-Checks-Passed: 5/5
X-Router-Decision: OBSERVE_ONLY
```

HTTP boundary probe:

```text
status: COLD_CALL_PASSED
governanceState: 010
authorityEffect: NONE
effect: NOT_PERFORMED
forwarded: false
applyProbeStatus: 405
applyProbeReason: EFFECT_ROUTE_FORBIDDEN
externalityStatus: NOT_ADJUDICATED
```

The local results are evidence that the declared checks and software ran over
the recorded checkout. They are not self-validating external adoption evidence,
canon elevation, or a Permit.

## How local work enters the shared ledger

1. Create a branch in your own clone or fork.
2. Add the proposal with its source and test evidence.
3. Open a pull request.
4. Let the protected repository's normal review path decide whether it merges.

Read [GROUP_RULES.md](GROUP_RULES.md) before contributing.
