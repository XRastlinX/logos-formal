@echo off
setlocal
set "NODE_ID=%~1"
set "PATHWAY=%~2"
if "%NODE_ID%"=="" set "NODE_ID=friend-node-01"
if "%PATHWAY%"=="" set "PATHWAY=codex"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1" -Identity "%NODE_ID%" -Pathway "%PATHWAY%"
exit /b %ERRORLEVEL%

