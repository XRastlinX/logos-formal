@echo off
setlocal
set "REPORT=%~1"
if "%REPORT%"=="" set "REPORT=cyonic-first-contact-report-01.json"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\trial.ps1" -Report "%REPORT%"
exit /b %ERRORLEVEL%

