# Requirements

## Laptop baseline

- Windows 10/11, macOS, or a current Linux distribution
- Git 2.30 or newer
- Go 1.24 or newer
- Network access during initial clone/fetch
- Local loopback access to `127.0.0.1`
- Approximately 250 MB free disk space

Node.js and Python are not required for the minimal Cyonic validation surface.

## Participation boundary

- Local AI sessions are interpretive and remain under `010`.
- No local script creates a Permit, Apply decision, merge, or canon elevation.
- Private keys, model credentials, and session transcripts do not enter Git.
- A local validation result proves only the recorded software interaction.
- Externality, comprehension, adoption, and authority require separate evidence.

## Network behavior

The setup script connects to:

```text
https://github.com/XRastlinX/logos-formal.git
```

The validation service binds to loopback only by default:

```text
127.0.0.1:18787
```

It is not intended to be exposed to a public network.

